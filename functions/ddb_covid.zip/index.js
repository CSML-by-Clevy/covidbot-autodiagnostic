const AWS = require("aws-sdk");
const { v4: uuidv4 } = require("uuid");

const {
  REGION,
  TABLE_NAME,
  ACCESS_KEY_ID,
  SECRET_ACCESS_KEY,
} = process.env;

const dynamodbclient = new AWS.DynamoDB.DocumentClient({
  region: REGION,
  accessKeyId: ACCESS_KEY_ID,
  secretAccessKey: SECRET_ACCESS_KEY,
})

async function handler(event) {
  try {
    const { data } = event;
    await dynamodbclient.put({
      TableName: TABLE_NAME,
      Item: {
        id: uuidv4(),
        timestamp: Date.now(),
        data,
      }
    }).promise();
    return { success: true };
  }
  catch (err) {
    return { success: false, reason: err };
  }
}

exports.handler = handler;
